# Smart School ERP — Project Status

> **Last updated:** May 2, 2026
> **Stack:** Express 5 + React + Vite + PostgreSQL + Drizzle ORM (pnpm monorepo)

---

## ✅ সম্পন্ন কাজ (Completed)

### 1. Authentication System
- [x] JWT-based login (`POST /api/auth/login`)
- [x] `/api/auth/me` endpoint to fetch current user
- [x] Password hashing with HMAC-SHA256 (no external library)
- [x] Token stored in `localStorage` as `erp_token`
- [x] Auto-attach Bearer token on every API call via `setAuthTokenGetter`
- [x] Login page with default credential hints

### 2. Role-Based Access Control (RBAC)
- [x] 5 roles defined: `SUPER_ADMIN`, `TEACHER`, `ACCOUNTANT`, `PARENT`, `STUDENT`
- [x] `requireAuth` middleware — verifies JWT on all protected routes
- [x] `requireAdmin` middleware — SUPER_ADMIN only (users, audit, etc.)
- [x] `requireFinance` middleware — SUPER_ADMIN + ACCOUNTANT (finance routes)
- [x] Teacher class-locking: teachers only see their own assigned class
- [x] Frontend route guards via `canAccessRoute()` → `AccessDenied` page for blocked routes
- [x] Role color badges in sidebar (purple = SUPER_ADMIN, blue = TEACHER, green = ACCOUNTANT)

| Route | SUPER_ADMIN | TEACHER | ACCOUNTANT |
|-------|-------------|---------|------------|
| /dashboard | ✅ | ✅ | ✅ |
| /students | ✅ | own class only | ❌ |
| /attendance | ✅ | own class only | ❌ |
| /classes | ✅ | view only | ❌ |
| /finance | ✅ | ❌ | ✅ |
| /users | ✅ | ❌ | ❌ |
| /audit | ✅ | ❌ | ❌ |

### 3. Student Management
- [x] CRUD: create, list, update, delete students
- [x] Auto-generated student ID (`STU-2026-XXXX`)
- [x] Search by name or student ID
- [x] Filter by class and enrollment status
- [x] Admission date tracking
- [x] Parent/guardian contact details

### 4. Class Management
- [x] Create and update classes with grade level and section
- [x] Assign teacher to class
- [x] Live student count per class
- [x] Teacher restricted to view-only (no create/update for TEACHER role)

### 5. Attendance System
- [x] Mark individual attendance (PRESENT, ABSENT, LATE, EXCUSED)
- [x] **Bulk attendance** for full class in one API call
- [x] Filter by class, date, student
- [x] Teacher can only mark attendance for their own class
- [x] Attendance summary widget on dashboard (per class, rate %)

### 6. Finance Module
- [x] **Fee Types** — configurable fee categories with amounts (recurring/one-time)
- [x] **Invoices** — auto-generated invoice numbers (`INV-202605-XXXX`), linked to student + fee type
- [x] **Transactions** — record payments, auto-update invoice paid amount + status
- [x] Invoice statuses: PENDING → PAID / OVERDUE
- [x] Finance stats on dashboard (monthly revenue, pending invoices, overdue)
- [x] Revenue trend chart (6-month line chart, collected vs pending)

### 7. Staff/User Management
- [x] CRUD for staff accounts (SUPER_ADMIN only)
- [x] Role assignment during creation
- [x] Active/inactive status toggle
- [x] Conflict check on email uniqueness

### 8. Dashboard
- [x] Stats cards: total students, teachers, classes, attendance rate, monthly revenue, total revenue, pending/overdue invoices, new admissions
- [x] Revenue trend chart (Recharts)
- [x] Today's attendance breakdown table (per class)
- [x] **Live Audit Feed** (SUPER_ADMIN only) — last 5 system events, auto-refreshes every 30s
- [x] Recent Activity card (TEACHER / ACCOUNTANT view)

### 9. Audit Log System
- [x] `audit_logs` table in PostgreSQL
- [x] `audit()` helper — fire-and-forget, never blocks requests
- [x] Auto-logging in all write routes:
  - Auth: `LOGIN`, `LOGIN_FAILED`
  - Users: `CREATE`, `UPDATE`, `DELETE`
  - Students: `CREATE`, `UPDATE`, `DELETE`
  - Classes: `CREATE`, `UPDATE`
  - Attendance: `BULK_ATTENDANCE`
  - Finance: `CREATE` (fee type, invoice), `PAYMENT` (transaction)
- [x] `GET /api/audit-logs` — filterable by action, entity, date range; paginated
- [x] **Audit Log page** (`/audit`) — SUPER_ADMIN only
  - Filter bar: action type, entity, date from/to
  - Color-coded action badges (CREATE=green, UPDATE=yellow, DELETE=red, PAYMENT=purple)
  - **Export to CSV** — respects active filters, downloads all matching records
  - Pagination (30 per page)
- [x] Live Audit Feed widget on Dashboard

### 10. Backend Architecture
- [x] Express 5 + esbuild (single `dist/index.mjs`)
- [x] Routes organized into subdirectories:
  ```
  routes/
    auth/index.ts       health/index.ts
    users/index.ts      dashboard/index.ts
    classes/index.ts    audit/index.ts
    students/index.ts   finance/index.ts
    attendance/index.ts
  ```
- [x] OpenAPI 3.1 spec → Orval codegen → React Query hooks + Zod schemas
- [x] Drizzle ORM for all DB queries (no raw SQL)
- [x] Pino structured logging on all requests

### 11. Frontend Architecture
- [x] React + Vite + TypeScript
- [x] Shadcn UI components (Card, Button, Input, Select, Dialog, Toast, Badge, Skeleton)
- [x] Wouter for routing (lightweight, path-based)
- [x] React Query for all server state
- [x] Responsive sidebar layout with mobile hamburger menu
- [x] Breadcrumb in header

---

## ❌ বাকি কাজ (Remaining / Planned)

### High Priority
- [ ] **Parent/Student portal** — separate login view for parents to see their child's attendance and invoices
- [x] **Password change** — `PUT /api/auth/password` with strength meter, show/hide toggle, wrong-password guard, same-password guard, audit logged
- [ ] **Forgot password / reset flow** — email-based reset (needs SMTP integration)
- [ ] **Overdue invoice auto-marking** — a cron job that marks PENDING invoices as OVERDUE past due date

### Medium Priority
- [ ] **Notifications** — in-app notification bell (new invoice, overdue, etc.)
- [ ] **Student document uploads** — profile photo, admit card, birth certificate
- [ ] **Timetable / Schedule** — class schedule per grade
- [ ] **Subject & Marks** — exam results, grade cards
- [ ] **Bulk student import** — CSV upload to add many students at once
- [ ] **SMS/WhatsApp alerts** — notify parents on absence (Twilio / local SMS gateway)

### Low Priority
- [ ] **Multi-school / Multi-branch** support (tenant isolation)
- [ ] **Dark/light theme toggle** for users
- [ ] **Attendance QR code** — generate QR for each student for faster scanning
- [ ] **Annual calendar** — holidays, events, exam schedule
- [ ] **Fee discount / scholarship** — partial discount on invoices

---

## 🔐 Default Credentials

| Role | Email | Password |
|------|-------|----------|
| Super Admin | admin@school.edu | admin123 |
| Teacher | sarah.ahmed@school.edu | teacher123 |
| Accountant | accountant@school.edu | accountant123 |

---

## 🗄️ Database Tables

| Table | Description |
|-------|-------------|
| `users` | Staff accounts (all roles) |
| `classes` | Grade-level classes with teacher assignment |
| `students` | Student profiles + enrollment |
| `attendance` | Daily per-student attendance records |
| `fee_types` | Configurable fee categories |
| `invoices` | Student fee invoices with status tracking |
| `transactions` | Payment records linked to invoices |
| `audit_logs` | Immutable event trail for all system actions |

---

## 📁 Key Files

```
artifacts/
  api-server/src/
    routes/             ← all route subdirectories
    middlewares/        ← requireAuth, requireRole
    lib/
      auth.ts           ← JWT create/verify, password hash
      audit.ts          ← audit log helper
  school-erp/src/
    pages/              ← one file per page
    components/
      Layout.tsx        ← sidebar + header
      AccessDenied.tsx  ← shown for blocked routes
    lib/
      auth.tsx          ← AuthContext, ROLE_CONFIG, usePermissions

lib/
  db/src/schema/        ← Drizzle table definitions
  api-spec/             ← OpenAPI 3.1 YAML (source of truth)
  api-zod/              ← generated Zod schemas
  api-client-react/     ← generated React Query hooks
```

---

## ⚡ Commands

```bash
# Push DB schema changes
pnpm --filter @workspace/db run push

# Regenerate API hooks from OpenAPI spec
pnpm --filter @workspace/api-spec run codegen

# Full typecheck
pnpm run typecheck

# Individual workflow restarts (done via Replit UI)
# API server: artifacts/api-server: API Server
# Frontend:   artifacts/school-erp: web
```

---

## 🔗 Routing

```
/            → → /dashboard (if logged in) or /login
/login       → LoginPage
/dashboard   → DashboardPage      (all roles)
/students    → StudentsPage       (SUPER_ADMIN, TEACHER)
/attendance  → AttendancePage     (SUPER_ADMIN, TEACHER)
/classes     → ClassesPage        (SUPER_ADMIN, TEACHER)
/finance     → FinancePage        (SUPER_ADMIN, ACCOUNTANT)
/users       → UsersPage          (SUPER_ADMIN)
/settings    → SettingsPage       (SUPER_ADMIN)
/audit       → AuditLogPage       (SUPER_ADMIN)
```

API routes all served under `/api` prefix (proxied to port 8080).
