# Smart School ERP

## Overview

A production-ready Smart School / Madrasa Management ERP system built on a pnpm workspace monorepo. Full-stack TypeScript with Express 5 backend, React + Vite frontend, PostgreSQL database, and Drizzle ORM.

## Architecture

```
artifacts/
  api-server/    — Express 5 REST API (JWT auth, all routes)
  school-erp/    — React + Vite frontend (wouter routing, PWA-enabled)
  mockup-sandbox/ — Storybook-like component previews

lib/
  db/            — Drizzle ORM schema + PostgreSQL client
  api-spec/      — OpenAPI 3.1 spec (source of truth)
  api-zod/       — Generated Zod validation schemas (from OpenAPI)
  api-client-react/ — Generated React Query hooks (from OpenAPI)
```

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Backend**: Express 5, Drizzle ORM, Zod validation
- **Frontend**: React + Vite, wouter routing, Shadcn UI, Recharts, Dexie.js (offline), vite-plugin-pwa
- **Database**: PostgreSQL (Drizzle ORM)
- **Auth**: JWT (manual HMAC-SHA256 implementation, no external library)
- **API codegen**: Orval (OpenAPI → React Query hooks + Zod schemas)
- **Build**: esbuild (API server), Vite (frontend)

## ERP Modules

| Module | Routes | Frontend Page |
|---|---|---|
| Auth | `POST /api/auth/login`, `GET /api/auth/me`, `PUT /api/auth/password` | `LoginPage.tsx` |
| Forgot Password | `POST /api/auth/forgot-password`, `POST /api/auth/reset-password` | `ForgotPasswordPage.tsx` |
| Students | CRUD `/api/students`, bulk import | `StudentsPage.tsx` |
| Bulk Import | `POST /api/students/bulk-import` (CSV) | Dialog in StudentsPage |
| Classes | CRUD `/api/classes` | `ClassesPage.tsx` |
| Attendance | `/api/attendance`, `/api/attendance/bulk` | `AttendancePage.tsx` |
| Attendance QR | QR code generation for each student | `AttendanceQRPage.tsx` |
| Finance | Fee types, invoices (with discount/scholarship), transactions | `FinancePage.tsx` |
| Subjects & Marks | CRUD `/api/subjects`, `/api/exam-results` | `SubjectsMarksPage.tsx` |
| Timetable | CRUD `/api/timetable` | `TimetablePage.tsx` |
| Notifications | `/api/notifications` with unread badge | `NotificationsPage.tsx` |
| Parent Portal | Filtered student view, attendance, invoices | `ParentPortalPage.tsx` |
| Calendar | CRUD `/api/calendar` (holidays, exams, events) | `CalendarPage.tsx` |
| Student Documents | `/api/students/:id/documents` | `StudentDocumentsPage.tsx` |
| Staff/Users | CRUD `/api/users` | `UsersPage.tsx` |
| Dashboard | Stats, revenue trend, attendance summary | `DashboardPage.tsx` |
| Audit Log | `GET /api/audit-logs` (SUPER_ADMIN only) | `AuditLogPage.tsx` |
| Report Card | Printable student report card | `ReportCardPage.tsx` |
| Asset Management | CRUD `/api/assets`, `/api/assets/:id/maintenance` | `AssetManagementPage.tsx` |
| Tenant Management | CRUD `/api/tenants`, public `/api/tenants/config` | `TenantsPage.tsx` |

## Multi-Tenant Architecture

Row-level tenant isolation using `tenantId` integer column on **every** table.

- **`tenants` table**: id, name, subdomain, primaryColor, primaryColorDark, logoUrl, contactEmail, plan, isActive
- **Tenant resolution** (Express middleware `requireTenant.ts`):
  1. `X-Tenant-ID` header (for API clients)
  2. Subdomain detection from `Host` header (e.g. `school1.erp.com`)
  3. Falls back to the default tenant (subdomain="default", id=1)
- **Frontend**: `TenantProvider` in `src/lib/tenant.tsx` detects subdomain on load, fetches `/api/tenants/config`, injects CSS variables (`--color-tenant-primary`, `--color-tenant-primary-dark`) into `<html>`, and updates page title
- **Dynamic theming**: Sidebar active item and icon use `tenant.primaryColor` via inline style; logo URL replaces School icon if set
- Default tenant seeded at id=1, subdomain="default"

## PWA / Offline-First

- **Service worker**: vite-plugin-pwa with Workbox, registered via `registerType: "autoUpdate"`
- **Offline DB**: Dexie.js (`src/lib/syncEngine.ts`) — IndexedDB schema for `mutationQueue`, `attendanceCache`, `invoiceCache`
- **Sync engine**: `useSyncEngine` hook (`src/hooks/useSyncEngine.ts`) listens for `window.addEventListener("online")` and auto-flushes queued mutations
- **Offline indicator**: Header shows amber "Offline" banner with pending count; blue "Sync N" button appears when reconnected with pending items
- **Runtime caching**: dashboard, students, classes, notifications API responses cached with NetworkFirst (5s timeout, 5min expiry)

## IoT / Asset Management

- **`hardware_assets`** table: name, type (COMPUTER/LAPTOP/TABLET/PRINTER/IP_CAMERA/ROUTER/SWITCH/SERVER/SMART_BOARD/UPS/OTHER), ipAddress, macAddress, serialNumber, location, status (ONLINE/OFFLINE/MAINTENANCE/RETIRED/STORAGE), manufacturer, model, purchaseDate, warrantyExpiry, purchaseCost
- **`maintenance_logs`** table: assetId, description, performedBy, performedAt, cost, nextMaintenanceDate
- **API**: `GET/POST /api/assets`, `GET/PUT/DELETE /api/assets/:id`, `POST /api/assets/:id/maintenance`
- **Frontend**: Status summary cards, filterable table with type icons, warranty expiry warnings, maintenance log drawer

## Database Tables

All tables have `tenantId integer NOT NULL DEFAULT 1` for multi-tenant isolation.

- `tenants` — registered schools/institutions
- `users` — staff with roles: SUPER_ADMIN, TEACHER, ACCOUNTANT, PARENT, STUDENT
- `classes` — grade-level classes with teacher assignments
- `students` — student profiles with class enrollment
- `attendance` — daily per-student attendance records
- `fee_types` — configurable fee categories
- `invoices` — student fee invoices with discount/scholarship + payment tracking
- `transactions` — payment records linked to invoices
- `audit_logs` — immutable event trail
- `subjects` — academic subjects with teacher assignments
- `exam_results` — student marks per subject/exam
- `timetable` — class schedule slots (day/period/subject/room)
- `notifications` — per-user notifications with read status
- `calendar_events` — annual calendar (holidays, exams, events, meetings, sports)
- `student_documents` — document links (birth certs, admit cards, etc.)
- `password_reset_tokens` — one-time password reset tokens (1hr expiry)
- `parent_students` — explicit parent↔student links (relationship field)
- `hardware_assets` — school hardware inventory
- `maintenance_logs` — per-asset maintenance history

## Backend Route Structure

All routes registered in `artifacts/api-server/src/routes/index.ts`.

Key conventions:
- `requireAuth` middleware validates JWT on all protected routes
- `requireAdmin` / `requireSuperAdmin` / `requireAcademic` for role-based access
- `resolveTenant` middleware attaches `req.tenant` from header/subdomain/default
- All writes produce an audit log entry
- Overdue invoice cron runs every 6 hours (`lib/overdue-cron.ts`)
- Tenant config cached in memory (60s TTL) for performance

## Frontend Routing

All routes defined in `artifacts/school-erp/src/App.tsx`.
Role-based route access defined in `artifacts/school-erp/src/lib/auth.tsx` (`ROLE_CONFIG`).

Role access matrix:
- **SUPER_ADMIN**: All routes (including /tenants, /assets)
- **TEACHER**: dashboard, students, attendance, classes, subjects, timetable, qr, notifications, calendar, report-card, assets
- **ACCOUNTANT**: dashboard, finance, notifications, calendar
- **PARENT**: dashboard, parent portal, notifications, calendar
- **STUDENT**: dashboard, notifications, calendar

## UI Features

- **Dark/light theme toggle** in header (persists via localStorage)
- **Notification bell** with unread badge in header (auto-refreshes every 30s)
- **Responsive sidebar** with role-filtered navigation
- **QR code generation** for each student (downloadable PNG, print-all)
- **Bulk import CSV** for students with download template + row-by-row results
- **Tenant-branded sidebar**: active nav item uses tenant's primaryColor, logo shown if configured
- **Offline indicator**: amber banner when offline, blue sync button when reconnected with pending mutations

## Default Credentials

| Role | Email | Password |
|---|---|---|
| Super Admin | admin@school.edu | admin123 |
| Teacher | sarah.ahmed@school.edu | teacher123 |
| Accountant | accountant@school.edu | accountant123 |

## Important Notes

- `zod/v4` cannot be used in api-server (esbuild bundling issue) — use manual validation or `zod` (v3 compat)
- `ROLE_CONFIG` in auth.tsx uses `const` assertion — must not export non-component things from the same file (causes HMR invalidation)
- Password reset tokens are returned in the API response (dev mode) — configure SMTP in production
- Student documents use URL-based storage (paste Drive/Dropbox links) — no file upload server
- Multi-tenancy uses row-level isolation (tenantId column), NOT schema-level isolation
- Default tenant id=1 ("Default School", subdomain="default") pre-seeded; all existing data has tenantId=1
- Subdomain detection on Replit dev domain falls back gracefully to default tenant
